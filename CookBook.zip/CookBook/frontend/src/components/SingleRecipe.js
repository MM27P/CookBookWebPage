import React, { Component } from "react";
import { 
	Typography,
	Paper,
	Grid,
	Card,
	CardMedia,
} from '@material-ui/core';
import { withStyles } from "@material-ui/styles";

const styles = theme => ({
  	RecipeRoot: {
  		width: "75%",
  		display: 'inline-block'
  	},
  	media: {
  		height: "90%",
  		width: "90%"
  	}
});	 	

class SingleRecipe extends Component {
	constructor(props){
		super(props);
	}


	render() {
		const { classes }  = this.props;
		return(
			<div>
				<br/>
				<Card elevation={10} classes={{root: classes.RecipeRoot}}>
					<Typography variant="h2" align="left" component="h2" gutterBottom>
	        			{this.props.recipe.name}
	      			</Typography>
	      			<Grid container>
	      				<Grid item xs={3}>
	      				<CardMedia
	      					className={classes.media}
	      					image={this.props.recipe.image_url}
	      					title={this.props.recipe.name}
	      				/>
	      				</Grid>
	      				<Grid item xs={9}>
	      				<Typography variant="h4" align="left">
		      			Ingridients
		      			</Typography>
						<Typography variant="h5" align="left" component="h5" gutterBottom style={{whiteSpace: 'pre-line'}}>
		        			{this.props.recipe.ingridients}
		      			</Typography>
		      			<Typography variant="h4" align="left">
		      			Description
		      			</Typography>
		      			<Typography variant="h5" align="left" gutterBottom style={{whiteSpace: 'pre-line'}}>
		        			{this.props.recipe.description}
		      			</Typography>
		      			</Grid>
	      			</Grid>
				</Card>
			</div>
		)
	}
}

export default withStyles(styles, {withTheme: true})(SingleRecipe);